# CRUD Python Module for the Grazioso Salvare animal shelter database
# This file lets other Python scripts or notebooks connect to MongoDB
# and perform create, read, update, and delete operations.

from pymongo import MongoClient


class AnimalShelter(object):
    """CRUD operations for the Animal collection in MongoDB."""

    def __init__(self, username='aacuser', password='aacpass'):
        # These are the connection settings for the MongoDB database.
        # The username and password can come from the dashboard input fields.
        USER = username
        PASS = password
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'

        # This creates the MongoDB client connection.
        # authSource tells MongoDB to authenticate against the aac database.
        self.client = MongoClient(
            'mongodb://%s:%s@%s:%d/%s?authSource=%s'
            % (USER, PASS, HOST, PORT, DB, DB)
        )

        # These lines select the correct database and collection.
        # In this project, the database is aac and the collection is animals.
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        """Insert one document into the animals collection."""

        # Make sure data was provided before trying to insert it.
        if data is not None:
            try:
                # insert_one adds one new document to the MongoDB collection.
                result = self.collection.insert_one(data)

                # acknowledged returns True if MongoDB accepted the insert.
                return result.acknowledged

            except Exception as error:
                # If something goes wrong, print the error and return False.
                print("Error while inserting document:", error)
                return False
        else:
            # If no data was sent to the method, raise an exception.
            raise Exception("Nothing to save, because data parameter is empty")

    def read(self, search_data):
        """Find documents that match the search_data query."""

        # Make sure a search query was provided.
        if search_data is not None:
            try:
                # find searches the collection and can return multiple documents.
                result = self.collection.find(search_data)

                # Convert the MongoDB cursor into a list so it is easier to use.
                return list(result)

            except Exception as error:
                # If the search fails, print the error and return an empty list.
                print("Error while reading documents:", error)
                return []
        else:
            # If no search data was sent, raise an exception.
            raise Exception("Nothing to search, because search_data parameter is empty")

    def update(self, search_data, update_data):
        """Update documents that match the search_data query."""

        # Make sure both the search query and update values were provided.
        if search_data is not None and update_data is not None:
            try:
                # update_many finds all matching documents and updates them.
                # The $set operator changes only the fields listed in update_data.
                result = self.collection.update_many(
                    search_data,
                    {"$set": update_data}
                )

                # Return the number of documents that were actually modified.
                return result.modified_count

            except Exception as error:
                # If the update fails, print the error and return 0.
                print("Error while updating documents:", error)
                return 0
        else:
            # If either value is missing, raise an exception.
            raise Exception("Search data and update data cannot be empty")

    def delete(self, search_data):
        """Delete documents that match the search_data query."""

        # Make sure a delete query was provided.
        if search_data is not None:
            try:
                # delete_many removes all documents that match the search query.
                result = self.collection.delete_many(search_data)

                # Return the number of documents deleted from the collection.
                return result.deleted_count

            except Exception as error:
                # If the delete fails, print the error and return 0.
                print("Error while deleting documents:", error)
                return 0
        else:
            # If no search data was sent, raise an exception.
            raise Exception("Nothing to delete, because search_data parameter is empty")